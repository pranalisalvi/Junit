package com.capgemini.appl.util;


import java.io.FileInputStream; 
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.naming.Context;

import com.capgemini.appl.exception.UniversityAdmissionException;

public class JndiUtil {
	private DataSource dataSource;

	
	
	/////////
	
	
public static Properties loadProperty(){    //copy paste code of connection
	Properties prop=new Properties();       
	InputStream in=null;
	try {
		in=new FileInputStream("emp.properties");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		prop.load(in);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return prop;
}                                        
public static Connection getConnection() throws UniversityAdmissionException{
	   Connection con=null;
	   Properties prop=loadProperty();
	   String url=prop.getProperty("oracle.url");
	   String driver=prop.getProperty("oracle.driver");
	   String uname=prop.getProperty("oracle.uname");
	   String upass=prop.getProperty("oracle.upass");
	   try{
		   Class.forName(driver);
		   //mylogger.info("Driver is loaded");     //this line 1
	   }catch(ClassNotFoundException e){
		   e.printStackTrace();
		   //mylogger.error("Driver is not loaded");   //line 2
	   }
	   try{
	   con=DriverManager.getConnection(url,uname,upass);
	   //mylogger.info("connected to databse");           //this 1 line
	   }catch(SQLException e){
		  // e.printStackTrace();
		  // mylogger.error("not connected");             //this 2 line add for logger
		   throw new UniversityAdmissionException("connection problem");
}

    return con;

}
	
	/////////
	
	
	
	
	/*
	public JndiUtil() throws UniversityAdmissionException {
		try {
			Context ctx = new InitialContext();// get referance to remote jndi
		//	ctx=new InitialContext(null);
			dataSource = (DataSource) ctx.lookup("java:/OracleDS");
		} catch (NamingException e) {
			e.printStackTrace();
		//	throw new UserException("PROBLEM IN CONNECTION(FAILED IN JNDI)",e);
		}
	}

	public Connection getConnection() throws SQLException{

		return dataSource.getConnection();

	}*/

}
