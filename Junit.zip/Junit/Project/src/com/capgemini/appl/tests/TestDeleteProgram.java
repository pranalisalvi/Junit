package com.capgemini.appl.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;
import com.capgemini.appl.service.UniversityServiceImpl;

public class TestDeleteProgram {
UniversityService service;
	
	@Before
	public void setup() throws UniversityAdmissionException {
		service = new UniversityServiceImpl();  //add this code
	}

	@Test
	public void testDeleteProgram() {
		
		try {
			assertEquals(true,service.deleteProgram("DB"));
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@After
	public void tearDown() throws Exception {
		service=null;
	}

}
