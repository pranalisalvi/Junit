package com.capgemini.appl.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;
import com.capgemini.appl.service.UniversityServiceImpl;

public class TestGetApplicationOnSheduledId {
UniversityService service;
	
	@Before
	public void setup() throws UniversityAdmissionException {
		service = new UniversityServiceImpl();  //add this code
	}

	@Test
	public void testGetApplicationOnSheduledId() {
		try {
			assertNotNull(service.getApplicationOnSheduledId("502"));
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@After
	public void tearDown() throws Exception {
		service=null;
	}

}
