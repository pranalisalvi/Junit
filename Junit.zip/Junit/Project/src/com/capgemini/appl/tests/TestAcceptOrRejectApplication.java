package com.capgemini.appl.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;
import com.capgemini.appl.service.UniversityServiceImpl;

public class TestAcceptOrRejectApplication {
UniversityService service;
	
	@Before
	public void setup() throws UniversityAdmissionException {
		service = new UniversityServiceImpl();  //add this code
	}
	@Test
	public void testAcceptOrRejectApplication() {
		Application app= new Application(1090,"applied");
		try {
			assertEquals(true,service.acceptOrRejectApplication(app));
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@After
	public void tearDown() throws Exception {
		service=null;
	}
}
